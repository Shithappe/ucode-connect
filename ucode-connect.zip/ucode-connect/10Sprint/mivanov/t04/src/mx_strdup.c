#include "../inc/header.h"

char *mx_strdup(const char *str) {
    int lenght = mx_strlen(str);
    char *dst = mx_strnew(lenght);

    dst = mx_strcpy(dst, str);
    return dst;
}
