#include "../inc/copyfile.h"

int main(int argc, char **argv)
{
    if (argc != 3){
        mx_printerr("usage: ");
        mx_printerr(argv[0]);
        mx_printerr(" [source_file] [destination_file]\n");
        return 0;
    }
    int fout;
    int fin;
    fout = open(argv[1], O_RDONLY);
    if (fout < 0){
        mx_printerr("mx_cp: ");
        mx_printerr(argv[1]);
        mx_printerr(": No such file or directory\n");
        return 0;
    }
    char c;
    fin = open(argv[2], O_CREAT | O_EXCL | O_WRONLY, S_IRUSR | S_IWUSR);
    while (read(fout, &c, 1))
        write(fin, &c,1);
    close(fin);
    close(fout);
}
