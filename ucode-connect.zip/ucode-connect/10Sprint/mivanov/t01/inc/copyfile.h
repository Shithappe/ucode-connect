#pragma once

#include <unistd.h>
#include <fcntl.h>

void mx_printerr(const char *s);
int mx_strlen(const char *s);
int main(int argc, char **argv);
