#include <unistd.h>
#include <fcntl.h>

int main(int argc, char **argv);
