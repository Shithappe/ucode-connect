#include "../inc/readfile.h"

int main(int argc, char **argv)
{
    if (argc != 2){
        write(2, "usage: ./read_file [file_path]\n", 31);
        return 0;
    }
    int file = open(argv[1], O_RDONLY);
    if (file == -1){
        write(2, "error\n", 6);
        return 0;
    }
    char c;
    ssize_t fread = read(file, &c, 1);
    while (fread > 0){
        write(1, &c, 1);
        fread = read(file, &c, 1);
    }
    if (fread < 0)
        write(2, "error\n", 6);
    close(file);
}
