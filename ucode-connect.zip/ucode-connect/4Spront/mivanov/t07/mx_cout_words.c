int mx_count_words(const char* str, char delimiter){
if (str == NULL) return -1;
else
{
    int i = 0;
    int count = 0;
    while (str[i]){
        if (str[i] == delimiter){
            if (i != 0) count++;
        } 
    }
}
}