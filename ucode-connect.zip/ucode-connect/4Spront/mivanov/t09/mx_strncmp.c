    #include <stdio.h>
    int mx_strncmp(const char* s1, const char *s2, int n){
    int i = 0;

    while (*s1 == *s2 && i < (n-1)) {
        if (*s1 == '\0' && *s2 == '\0')
            return 0;
        s1++;
        s2++;
        i++;
    }
    return *s1 - *s2;
}