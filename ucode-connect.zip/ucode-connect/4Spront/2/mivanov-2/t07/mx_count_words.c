int mx_count_words(const char *str, char delimiter){
  int count_words = 0;
  int word_start = 0;
  for(int i = 0; str[i] != '\0'; i++){
    if(str[i] != delimiter && word_start == 0){
      word_start = 1;
      count_words += 1;
    }
    else if(str[i] == delimiter){
      word_start = 0;
    }
  }
  return count_words;
}