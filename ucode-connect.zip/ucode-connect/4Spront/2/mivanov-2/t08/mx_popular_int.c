int mx_popular_int(const int *arr, int size){
  int most_pop_num = arr[0];
  int most_pop_count = 1;

  for (int i = 0; i < size; i++) {
    int new_mst_pop_n = arr[i];
    int new_mst_pop_c = 0;

    for (int j = 0; j < size; j++) {
        if (arr[j] == new_mst_pop_n){
          new_mst_pop_c++;
        }
    }
    if (new_mst_pop_c > most_pop_count) {
      most_pop_count = new_mst_pop_c;
      most_pop_num = new_mst_pop_n;
    }
  }
  return most_pop_num;
}
