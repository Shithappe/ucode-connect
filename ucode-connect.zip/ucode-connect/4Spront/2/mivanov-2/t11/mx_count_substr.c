char *mx_strstr(const char *s1, const char *s2);
int mx_strlen(const char *s);
int mx_count_substr(const char *str, const char *sub){
  int count_sub = 0;
  if(mx_strlen(sub) == 0)
  {
    return count_sub;
  }
  char *ptr = mx_strstr(str, sub);
  while(ptr != 0){
    count_sub++;
    ptr = mx_strstr(ptr+1, sub);
  }
  return count_sub;
}
