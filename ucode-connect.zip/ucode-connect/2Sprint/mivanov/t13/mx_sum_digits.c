int mx_sum_digits(int num)
{
  if (num < 0) n = -num;
  while(num > 0)
  {
    sum = sum + n % 10;
    num = num / 10;
  }
return sum;
}
