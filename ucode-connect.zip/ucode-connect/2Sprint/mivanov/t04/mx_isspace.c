#include <stdbool.h>

bool mx_isspace(int c) {
    if (c == 32) return True;
else return False;
}
