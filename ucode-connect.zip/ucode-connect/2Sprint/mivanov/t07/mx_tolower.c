int mx_tolower(int c) {
if (c >= 'a' && c <= 'z') {
return c;
}
else {
return (c + 32);
}
}
