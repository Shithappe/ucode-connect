#include <stdbool.h>

bool mx_isupper(int c) {
return ((c >= 'A' && c <= 'Z') ? true : false);
}
