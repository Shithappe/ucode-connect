#include <unistd.h>

void mx_printsrt(canst char *s);

void mx_is_positive(int i){
  if (i > 0) mx_pritsrt("positive\n");
  else if (i < 0) mx_pritsrt("negative\n");
  else mx_pritsrt("zero\n");
}