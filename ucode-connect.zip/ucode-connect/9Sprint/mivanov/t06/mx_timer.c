#include <time.h>

double mx_timer(void (*f)()){
    double start_time =  clock();
    (*f) ();
    double time = (clock() - start_time) / (double)10; 
    return time;
}
