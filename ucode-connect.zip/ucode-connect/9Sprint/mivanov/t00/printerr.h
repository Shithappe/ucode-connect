#pragma once

#include <stdio.h>
#include <unistd.h>


int mx_strlen(const char *s);
