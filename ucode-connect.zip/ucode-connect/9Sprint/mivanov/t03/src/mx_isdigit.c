#include "minilibmx.h"

bool mx_isdigit(char c) {
    return (char)c >= '0' && (char)c <= '9';
}
