clang -std=c11 -Wall -Wextra -Werror -Wpedantic -c *.c
ar -scr minilibmx.a *.o
