void mx_printchar(char c);

int mx_atoi(const char *str);

void mx_printint(int n);

static void SetbArrNullElements(char *arr);

static void PrintIntArrElements(char *arr);

int main(int argc, char** argv) {
    if (argc <= 1) 
        return 0;
    long temp = 0;
    char sign = 0;
    char bArr[32];
    unsigned bArrCounter;
	for (int i = 1; i < argc; ++i) {
        SetbArrNullElements(bArr);
        temp = mx_atoi(argv[i]);
        sign = 0;
        if (temp < 0) {
            temp = 2147483647 + temp + 1;
            sign = 1;
        }
        bArrCounter = 31;
        while(temp > 0) {
            bArr[bArrCounter] = (char)(temp % 2);
            --bArrCounter;
            temp /= 2;
        }
        bArr[0] = sign;
        PrintIntArrElements(bArr);
    }
    return 0;
}

static void SetbArrNullElements(char *arr) {
    for (unsigned i =0; i < 32; ++i) {
        arr[i] = 0;
    }
}

static void PrintIntArrElements(char *arr) {
    for (unsigned i = 0; i < 32; ++i) {
        mx_printint(arr[i]);
    }
    mx_printchar('\n');
}
