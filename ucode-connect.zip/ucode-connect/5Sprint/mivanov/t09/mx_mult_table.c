#include <stdbool.h>

void mx_printchar(char c);

int mx_atoi(const char *str);

void mx_printint(int n);

bool mx_isspace(char c);

bool mx_isdigit(int c);

int mx_strlen(const char *s);

static bool isValidArgs(char **argv);

static bool IsValidNumber(char *num);

int main(int argc, char** argv) {
    if (argc < 3)
        return 0;
    if (!isValidArgs(argv))
        return 0;
    long min = mx_atoi(argv[1]);
    long max = mx_atoi(argv[2]);
    if (min <= 0 || max <=0)
        return 0;
    if(min > max)
    {
        long tmp = min;
        min = max;
        max = tmp;
    }
    for(int i = min; i<=max; ++i) {
        for (int j = min; j<=max; ++j) {
            if (j != min)
                mx_printchar('\t');
            mx_printint(i*j);
        }
        mx_printchar('\n');
    }
    return 0;
}

static bool isValidArgs(char **argv) {
    for (int i=1; i<3; ++i) {
        if (!IsValidNumber(argv[i])) {
            return false;
        }
    }
    return true;
}

static bool IsValidNumber(char *num) {
    bool bIsSignFound = false;
    bool bIsAfterDigit = false;
    while (*num) {
        if (!mx_isspace(*num)) {
            if (!mx_isdigit(*num)) {
                if ((*num == '+' || *num == '-') && !bIsSignFound && !bIsAfterDigit) {
                    ++num;
                    continue;
                }
                else {
                    return false;
                }
            }
            else 
                bIsAfterDigit = true;
        }
        else
            return false;
    ++num;
    } 
    return true;
}
