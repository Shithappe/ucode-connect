void mx_printstr(const char *s);
void mx_printchar(char c);

int main(int argc, char** argv) 
{  
    for (int i = 0; i < argc; ++i){
        mx_printsttr(argv[i]);
    mx_printchar('\n');
    }
    return 0; 
}
