#include <stdbool.h>

bool mx_isdigit(int c);

bool mx_isspace(char c);

int mx_atoi(const char *str)
{
  char sign = -1;
  char flag = 0;
  int digit = 0;
  for (unsigned int i = 0; str[i]; ++i) {
    if (!mx_isspace(str[i]))
      if (mx_isdigit(str[i])) {
        flag = 1;
        digit = digit * 10 + (str[i] - '0');
      }
      else
        if (sign == -1 && (str[i] == '-' || str[i] == '+') && mx_isdigit(str[i+1]))
          sign = str[i];
        else
          return (sign == '-' ? -digit : digit);
    else
      if (flag != 0)
        return (sign == '-' ? -digit : digit);;
  }
  return (sign == '-' ? -digit : digit);
}
