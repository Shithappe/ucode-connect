#include <stdbool.h>

void mx_printchar(char c);

bool mx_isdigit(int c);

int mx_atoi(const char *str);

void mx_printint(int n);

bool mx_isspace(char c);

static bool IsValidNumber(char *num);

int main(int argc, char** argv) {
	if (argc <= 1)
		return 0;
	int sumArgs = 0;
    for (int i = 1; i < argc; ++i) {
    	if(IsValidNumber(argv[i])) {
    		sumArgs+=mx_atoi(argv[i]);
    	}	
    }
    mx_printint(sumArgs);
    mx_printchar('\n');
    return 0;
}

static bool IsValidNumber(char *num) {
	bool bIsSignFound = false;
	bool bIsAfterDigit = false;
	while (*num) {
		if (!mx_isspace(*num)) {
			if (!mx_isdigit(*num)) {
				if ((*num == '+' || *num == '-') && !bIsSignFound && !bIsAfterDigit) {
					++num;
					continue;
				}
				else {
					return false;
				}
			}
			else 
				bIsAfterDigit = true;
		}
		else
			return false;
	++num;
	} 
	return true;
}
