void mx_printchar(char c);

void mx_printint(int n) 
{
  if (n != 0) {
    char s[20];
    int j = 0;
    int i = 0;
    long value = n;
    if (value < 0)
      value = -value;
    while (value != 0) {
      s[i++] = value % 10 + '0';
      value /= 10;
    }
    if (n < 0)
      s[i++] = '-';
    for (j = i - 1; j >= 0; --j) {
      mx_printchar(s[j]);
    }
  } else {
    mx_printchar('0');
  }
}
