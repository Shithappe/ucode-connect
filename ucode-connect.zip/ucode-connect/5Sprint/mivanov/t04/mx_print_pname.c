void mx_printchar(char c);

char *mx_strchr(const char *s, int c);

void mx_printstr(const char *s);

int main(int argc, char** argv) {
	char *pname = argv[argc - argc];
	char *args = pname;
    while(args != 0) {
    	pname = args;
    	args = mx_strchr(args, '/');
    	if (args != 0)
    		++args;
    }
    mx_printstr(pname);
    mx_printchar('\n');
    return 0;
}
