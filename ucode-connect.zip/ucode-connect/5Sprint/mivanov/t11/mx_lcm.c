int mx_gcd(int, int);

int mx_lcm(int a, int b)
{
    int tmp = mx_gcd(a, b);
    if (tmp <= 0)
        return 0; 
    if (0 > a * b / mx_gcd(a, b))
        return -(a * b / mx_gcd(a, b));
    else
        return a * b / mx_gcd(a, b);
    return 0;
}
