int mx_gcd(int a, int b)
{
    if (b != 0)
    {
        if (0 > mx_gcd(b, a % b))
        {
            return -(mx_gcd(b, a % b));
        }
        else
        {
            return mx_gcd(b, a % b);
        }
    }
        return a;
}
