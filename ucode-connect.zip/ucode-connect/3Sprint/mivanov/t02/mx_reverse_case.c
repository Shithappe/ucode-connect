#include "stdio.h"
#include "stdbool"
#include "string.h"

bool mx_islower(int c);
bool mx_isupper(int c);
int mx_tolower(int c);
int mx_toupper(int c);

void mx_reverse_case(char *s){
 for (unsigner long int index = 0; index < strlen(s); index++){
  if (mx_islower(s[index]) == true) s[index] = mx_toupper(s[indes]);
  else if ((mx_isupper(s[index]) == true) s[index] = mx_tolower(s[indes]);
 }
 printf("%s", s);
}
