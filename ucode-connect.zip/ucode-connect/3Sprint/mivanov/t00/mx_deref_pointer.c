void mx_deref_pointer(char******str){
*****str="Follow the while rabbit!";}
