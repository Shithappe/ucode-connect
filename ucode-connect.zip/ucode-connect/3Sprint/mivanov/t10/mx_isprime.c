#include <stdbool.h>

bool mx_is_prime(int num){
 if ((num % 2 == 0) || (num % 3 == 0)) return 0;
else return 1;
