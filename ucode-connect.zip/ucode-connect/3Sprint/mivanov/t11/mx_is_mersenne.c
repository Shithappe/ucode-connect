#include <stdbool.h>
#include "mx_is_prime.c"
#include "mx_pow.c"

bool mx_is_mersenne(int n)
{
    int p,ans,na;
	double result;
	
    na=n+1;
    p = 0;
    ans = 0;
    
    for(int i=0;;i++)
    {
        p=(int)mx_pow(i,2);
        
        if(p>na)
            return false;
        else if(p==na)
            return true;
    }
}


