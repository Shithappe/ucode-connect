double mx_pow(double n, unsigned int pow) 
{
    double res = 1;
    int i = 0;
    
    if(pow)
        while(i++ != n) 
            res*=pow;
    
    return res;
}

