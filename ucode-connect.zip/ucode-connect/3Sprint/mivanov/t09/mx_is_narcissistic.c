#include "mx_pow.c"
#include <stdbool.h>

bool mx_is_narcissistic(int num) 
{ 
    int count = 0; 
    int dup = num; 
    int sum = 0; 
  
    while (dup != 0) {
        dup /= 10;    
        ++count;
    }
    dup = num;
    
    while (dup) { 
        sum += mx_pow(count, dup % 10 ); 
        dup /= 10; 
    } 
  
    return (num == sum); 
}
 

