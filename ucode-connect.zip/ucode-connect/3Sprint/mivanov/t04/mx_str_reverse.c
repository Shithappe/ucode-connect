#include "mx_swap_char.c"
#include "mx_strlen.c"

void mx_str_reverse(char* s)
{
    int i = 0, j = mx_strlen(s) - 1;
    
    while(i != j && i < j)
    {
        mx_swap_char(&s[i],&s[j]);
        i++;
        j--;
    }
}

