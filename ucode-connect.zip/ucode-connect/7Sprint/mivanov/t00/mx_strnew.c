#include "unistd.h"
#include "stdlib.h"

char *mx_strnew(const int size) {
	char *string1 = (char *)malloc(size+1);
	if (string1 == NULL) return string1;
	for(int i = 0; i < size+1; i++)
		string1[i] = '\0';
	return string1;
}
