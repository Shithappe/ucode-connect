#include <stdlib.h>
#include "stdbool.h"

char *mx_strncpy(char *dst, const char*src, int len);
int mx_count_words(const char* str, char delimiter);
char *mx_strnew(const int size);

char** mx_strsplit(char const* s, char c) {
    if(s == NULL) return NULL;
    int size = mx_count_words(s, c);
    char **arr = (char **)malloc(size);
    int count = 0;
    for (int i = 0; i < size; i++) {
        while(*s == c) {
            s++;
        }
        while(*s != c) {
            count++;
            s++;
        }
        s -= count;
        arr[i] = (char*)mx_strnew(count);
        for (int j = 0; j < count; j++) {
            arr[i][j] = s[j];
        }
        s+=count;
        count = 0;
    }
    return arr;
}


