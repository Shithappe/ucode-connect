#include "stdlib.h"
#include "stdbool.h"

bool mx_isspace(char);
char *mx_strnew(const int size);

char* mx_strtrim(const char*str) {
    if (str == NULL) return NULL;
    int size=0, left=0, right=0;
    while(*str) {
        size++;
        str++;
    }
    str -= size;
    while(*str && mx_isspace(*str)) {
        str++;
        left++;
    }
    str -= left;
    for (int i = size - 1; i >= left; i--) {
        if(!mx_isspace(str[i])) break;
        right++;
        
    }
    char *arr = mx_strnew(size-left-right);
    for (int i = left, j=0; i <size-right; i++, j++) arr[j] = str[i];
    return arr;
}
