#include "stdlib.h"
#include "stdbool.h"

char* mx_strtrim(const char*str);
char *mx_strnew(const int size);
bool mx_isspace(char c);

char* mx_del_extra_whitespaces(const char*str) {
    int size_arr = 0, size_arr2 = 0;
    char *arr = mx_strtrim(str);
    if (arr == NULL) return NULL;
    while(*arr) {
        if (!mx_isspace(*arr) || (mx_isspace(*arr) && !mx_isspace(*(arr+1)))) {
            size_arr2++;
        }
        arr++;
        size_arr++;
    }
    arr -= size_arr;
    char *arr2 = mx_strnew(size_arr2);
    for (int i = 0, j = 0; i < size_arr; i++) {
        if (!mx_isspace(arr[i]) || (mx_isspace(arr[i]) && !mx_isspace(arr[i+1]))) { 
            arr2[j] = arr[i];
            j++;
        }
    }
    return arr2;
}

