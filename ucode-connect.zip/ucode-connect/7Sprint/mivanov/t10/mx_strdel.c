#include "stdlib.h"

void mx_strdel(char** arr) {
  free(*arr);
  *arr = NULL;
}
