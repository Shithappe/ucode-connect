#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void mx_del_strarr(char*** arr) {
  for (int i = 0; (*arr)[i] != NULL; i++)
    mx_strdel(&((*arr)[i]));
  free(*arr);
  *arr = NULL;
}
