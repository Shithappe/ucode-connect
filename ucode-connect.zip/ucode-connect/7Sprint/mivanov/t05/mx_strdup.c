#include <stdlib.h>
char *mx_strnew(const int size);
char* mx_strcpy(char *dst, const char *src);
int mx_strlen(const char *s);

char *mx_strdup(const char *src)
{
    char *str = mx_strnew(mx_strlen(src));
    mx_strcpy(str, src);
    return str;
}

