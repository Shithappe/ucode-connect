#include "stdlib.h"

char *mx_strdup(const char *src);
char *mx_strcat(char *s1, const char *s2);

char* mx_concat_words(char** words) {
    if (words[0] == NULL) return NULL;
    if (words[1] == NULL) return words[0];
    int i = 1;
    char *arr = mx_strdup(words[0]);
    while(words[i] != NULL) {
        arr = mx_strcat(arr, words[i]);
        i++;
    }
    return arr;
}
