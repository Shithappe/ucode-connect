#include "stdlib.h"
void mx_strdel(char** str) {
    int i = 0;
    while (str[i] != NULL) {
        free(str[i]);
	i++;
    }
    free(str);
    str = NULL;
}
