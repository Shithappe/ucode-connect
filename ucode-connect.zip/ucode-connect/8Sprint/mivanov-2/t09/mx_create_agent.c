#include "only_smiths.h"

t_agent *mx_create_agent(char *name, int power, int strength){
        if(name != NULL && power >= 0 && strength >= 0) {
                t_agent *a;
                a = malloc(16);
                a->name = mx_strdup(name);
                a->power = power;
                a->strength = strength;
                return a;
        }
        else {
                return NULL;
        }
}

