char *mx_strcpy(char *, const char *);
char *mx_strnew(const int);
int mx_strlen(const char *);

char *mx_strdup(const char *str) {
    return mx_strcpy(mx_strnew(mx_strlen(str)), str);
}

