#ifndef exterminate_agents_h
#define exterminate_agents_h

#include <stdio.h>
#include <stdlib.h>
#include "agent.h"

typedef struct s_agent
{
        char *name;
        int power;
        int strength;
}       t_agent;


char *mx_strdup(const char *str);
char *mx_strcpy(char *dst, const char *src);
int mx_strlen(const char *s);
char *mx_strnew(const int size);
t_agent *mx_create_agent(char *name, int power, int strength);
int mx_strcmp(const char *s1, const char *s2);
t_agent **mx_only_smiths(t_agent **agent, int strength);
void mx_exterminate_agents(t_agent ***agents);

#endif