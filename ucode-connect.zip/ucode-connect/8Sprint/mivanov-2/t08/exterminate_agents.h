#pragma once

#include "agent.h"

#include <stdlib.h>

void mx_exterminate_agents(t_agent ***agents);
