#ifndef NBR_TO_HEX_H
#define NBR_TO_HEX_H

#include <stdlib.h>

char *mx_strnew(const int size);
char *mx_nbr_to_hex(unsigned long nbr);

#endif
