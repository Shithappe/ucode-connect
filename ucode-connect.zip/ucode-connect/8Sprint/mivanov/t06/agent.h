#ifndef AGENT_HEADER
#define AGENT_HEADER

typedef struct s_agent
{
  char *name;
  int power;
  int strength;
}              t_agent;


#endif
