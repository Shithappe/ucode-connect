#include "create_agent.h"
char *mx_strdup(const char *str) {
  char *cpy = mx_strnew(mx_strlen(str));
  cpy = mx_strcpy(cpy, str);
  return (char *)cpy;
}
