#include "duplicate.h"

t_intarr *mx_del_dup_sarr(t_intarr *src) {
  t_intarr *dst = (t_intarr *)malloc(4 * src->size);
  dst->arr = mx_copy_int_arr(src->arr, src->size);
  dst->size = src->size;
  if (src->arr) {
    for(int i = 0; i < src->size; i++) {
      for(int j = i + 1; j < src->size; ) {
        if(dst->arr[j] == dst->arr[i]) {
          for(int k = j; k < src->size; k++) {
            dst->arr[k] = dst->arr[k + 1];
          }
          src->size--;
        }
        else {
          j++;
        }
      }
    }
    dst->size = src->size;
    return dst;
  }
  return NULL;
}