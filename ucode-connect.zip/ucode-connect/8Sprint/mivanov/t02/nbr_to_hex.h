#ifndef NUM_TO_HEX_HEADER
#define NUM_TO_HEX_HEADER
#ifdef DEBUG
#define DEBUG_ONLY(expr) expr
#else
#define DEBUG_ONLY(expr)
#endif

#include <stdio.h>
#include <stdlib.h>

char *mx_strnew(const int size);
char *mx_nbr_to_hex(unsigned long nbr);

#endif
