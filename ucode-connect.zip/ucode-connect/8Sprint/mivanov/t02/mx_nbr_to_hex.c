#include "nbr_to_hex.h"
char *mx_nbr_to_hex(unsigned long nbr) {
  if (nbr < 0) {
    return 0;
  }
  char *hex = mx_strnew(100);
  int i = 0;
  while (nbr != 0) {
    unsigned long temp = nbr % 16;

    if (temp < 10) {
      hex[i] = temp + 48;
      i++;
    }
    else {
      hex[i] = temp + 87;
      i++;
    }
    nbr = nbr / 16;
  }
  char *res = mx_strnew(i);

  for (int j = i -1, k = 0; j >= 0 && k < i; j--, k++) {
    res[k] = hex[j];
  }
  free(hex);
  return res;
}
// to run it add -DDEBUG flag 
DEBUG_ONLY(
  int main() {
    printf("%s\n", mx_nbr_to_hex(52));
    printf("%s\n", mx_nbr_to_hex(1000));
  }
)
