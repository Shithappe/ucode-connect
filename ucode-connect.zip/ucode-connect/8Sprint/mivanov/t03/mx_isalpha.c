#include <stdbool.h>
bool mx_isalpha(int c){
  bool is_alpha;
  if((c > 64 && c < 91) || (c > 96 && c < 123)){
    is_alpha = true;
  }
  else{
    is_alpha = false;
  }
  return is_alpha;
}
