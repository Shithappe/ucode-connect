#ifndef HEX_TO_NBR_HEADER
#define HEX_TO_NBR_HEADER

#ifdef DEBUG
#define DEBUG_ONLY(expr) expr
#else
#define DEBUG_ONLY(expr)
#endif

#include <stdio.h>
#include <stdbool.h>
bool mx_isalpha(int c);
bool mx_isdigit(int c);
bool mx_islower(int c);
bool mx_isupper(int c);

unsigned long mx_hex_to_nbr(const char *hex);

#endif
