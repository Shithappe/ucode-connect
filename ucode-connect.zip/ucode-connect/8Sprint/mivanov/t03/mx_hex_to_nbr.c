#include "hex_to_nbr.h"
unsigned long mx_hex_to_nbr(const char *hex) {
  unsigned long res = 0;
  unsigned long base = 1;
  int len = 0;
  while(hex[len] != 0){
    len++;
  }
  for (int i = len - 1; i >= 0; i--) {
    if(mx_isdigit(hex[i])) {
      res += (hex[i] - 48) * base;
      base *= 16;
    }
    else if(mx_isalpha(hex[i])) {
      if(mx_isupper(hex[i])) {
        res += (hex[i] - 55) * base;
        base *= 16;
      }
      else if(mx_islower(hex[i])) {
        res += (hex[i] - 87) * base;
        base *= 16;
      }
    }
    else {
      return 0;
    }
  }
  return res;
}

DEBUG_ONLY(
  int main() {
    printf("%lu\n", mx_hex_to_nbr("C-4"));
    printf("%lu\n", mx_hex_to_nbr("FADE"));
    printf("%lu\n", mx_hex_to_nbr("ffffffffffff"));
  }
)
