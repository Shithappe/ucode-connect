#include <create_new_agent.h>
t_agent **mx_create_new_agent(char **name, int *power, int *strength, int count) {
  t_agent **arr_agents = (t_agent **)malloc(sizeof(t_agent) * (count + 1));

  for(int i = 0; i < count + 1; i++) {
    if (i == count) {
      arr_agents[i] = NULL;
    }
    
  }
}